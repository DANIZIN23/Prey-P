function onEvent(name, value1, value2)
local stages = getDataFromSave(value1)
stages = {
	['None'] = function()
		return
	end,
['maze'] = function()
	makeAnimatedLuaSprite('Maze', 'Maze', -600, -200)
	luaSpriteAddAnimationByPrefix('Maze', 'bop', 'Stage', 16, true)
	scaleObject('Maze', 1.2, 1.2);
	addLuaSprite('Maze',  false)
	end,    
	['redstatic'] = function()
		makeAnimatedLuaSprite('redstatic', 'redstatic', -600, -200)
	luaSpriteAddAnimationByPrefix('redstatic', 'bop', 'Stage', 16, true)
	scaleObject('redstatic', 1.2, 1.2);
	addLuaSprite('redstatic',  false)
	end,
	['edgymaze'] = function()
makeAnimatedLuaSprite('edgymaze', 'edgymaze', -600, -200)
	luaSpriteAddAnimationByPrefix('edgymaze', 'bop', 'Stage', 16, true)
	scaleObject('edgymaze', 1.3, 1.3);
	addLuaSprite('edgymaze',  false)
	end,
	['mazeB'] = function()
	makeAnimatedLuaSprite('mazeB', 'mazeB', -600, -200)
	luaSpriteAddAnimationByPrefix('mazeB', 'bop', 'Stage', 16, true)
	scaleObject('mazeB', 1.2, 1.2);
	addLuaSprite('mazeB',  false)
	end,
	['blackstatic'] = function()
	makeAnimatedLuaSprite('blackstatic', 'blackstatic', -600, -200)
	luaSpriteAddAnimationByPrefix('blackstatic', 'bop', 'Stage', 16, true)
	scaleObject('blackstatic', 1.2, 1.2);
	addLuaSprite('blackstatic',  false)
    end,
    ['Zardy'] = function()
    makeAnimatedLuaSprite('Zardy', 'Zardy', -600, -200)
	luaSpriteAddAnimationByPrefix('Zardy', 'bop', 'Stage', 16, true)
	scaleObject('Zardy', 1.2, 1.2);
	addLuaSprite('Zardy',  false)
	end,
	['Swamp Too Bad'] = function()
	makeLuaSprite('Swamp Too Bad', 'Swamp Too Bad', -500, -300);
	setLuaSpriteScrollFactor('Swamp Too Bad', 0.9, 0.9);
	end,
	
		['swamp'] = function()
	makeLuaSprite('SawmpBack', 'SawmpBack', -508, -330);
	scaleObject('SawmpBack', 1, 1);
	setScrollFactor('SawmpBack', 1, 1);
	setProperty('SawmpBack.antialiasing', true);
	addLuaSprite('KermAssets2',  true)

	makeLuaSprite('SwampFront', 'SwampFront', -552, -46);
	scaleObject('SwampFront', 1, 1);
	setScrollFactor('SwampFront', 1, 1);
	setProperty('SwampFront.antialiasing', true);
	addLuaSprite('KermAssets2',  true)

	setScrollFactor('gfGroup', 0.95, 0.95);
	setProperty('gfGroup.antialiasing', true);
	setObjectOrder('gfGroup', 2);

	setScrollFactor('dadGroup', 1, 1);
	setProperty('dadGroup.antialiasing', true);
	setObjectOrder('dadGroup', 3);

	setScrollFactor('boyfriendGroup', 1, 1);
	setProperty('boyfriendGroup.antialiasing', true);
	setObjectOrder('boyfriendGroup', 4);

	makeAnimatedLuaSprite('BobAssets', 'BobAssets', 1138, 412);
	scaleObject('BobAssets', 1, 1);
	luaSpriteAddAnimationByPrefix('BobAssets', 'bop', 'Idle', 27, true)
	setScrollFactor('BobAssets', 1, 1);
	setProperty('BobAssets.antialiasing', true);
	addLuaSprite('BobAssets2',  true)

	makeAnimatedLuaSprite('KermAssets', 'KermAssets', -350, 368);
	scaleObject('KermAssets', 1, 1);
	luaSpriteAddAnimationByPrefix('KermAssets', 'bop', 'Idle', 27, true)
	setScrollFactor('KermAssets', 1, 1);
	setProperty('KermAssets.antialiasing', true);
	addLuaSprite('KermAssets2',  true)

	makeAnimatedLuaSprite('SwaggiestInTheLandAssets2', 'SwaggiestInTheLandAssets2', 856, -180);
	scaleObject('SwaggiestInTheLandAssets2', 1, 1);
	luaSpriteAddAnimationByPrefix('SwaggiestInTheLandAssets2', 'bop', 'Idle', 27, true)
	setScrollFactor('SwaggiestInTheLandAssets2', 1, 1);
	setProperty('SwaggiestInTheLandAssets2.antialiasing', true);
		addLuaSprite('SwaggiestInTheLandAssets2',  true)
	end,
	['starecrown'] = function()
	    makeLuaSprite('stare_back', 'stare_back', -600, -300);
    setScrollFactor('stare_back', 0.9, 0.9);
    
    makeLuaSprite('stare_front', 'stare_front', -600, -250);
    setScrollFactor('stare_front', 0.9, 0.9);
    
    addLuaSprite('stare_back', false);
    addLuaSprite('stare_front',false);
    end,
    ['randy'] = function()
    	makeLuaSprite('stage','stagerandy lol',-280,-130)
	addLuaSprite('stage',false)
	setLuaSpriteScrollFactor('stage', 1.1, 1.1)
end,
['mazeday'] = function()
	makeLuaSprite('stage','mazeday',-280,-130)
	addLuaSprite('stage',false)
	setLuaSpriteScrollFactor('stage', 1.2, 1.2)
	end,
	['maze9'] = function()
	makeAnimatedLuaSprite('Maze9', 'Maze9', -600, -200)
	luaSpriteAddAnimationByPrefix('Maze9', 'bop', 'Stage', 16, true)
	scaleObject('Maze9', 1.2, 1.2);
	addLuaSprite('Maze9',  false)
	end,
	['jofini'] = function()
	makeLuaSprite('stage','stagejofini lol',-280,-130)
	addLuaSprite('stage',false)
	setLuaSpriteScrollFactor('stage', 1.2, 1.2)
end,
['jacobe'] = function()
	makeLuaSprite('stage','stagejacobe lol',-280,-130)
	addLuaSprite('stage',false)
	setLuaSpriteScrollFactor('stage', 1.2, 1.2)
end,
['gene'] = function()
	makeLuaSprite('stage','stagegene lol',-280,-130)
	addLuaSprite('stage',false)
	setLuaSpriteScrollFactor('stage', 1.2, 1.2)
end,
['fishbrain'] = function()
	makeLuaSprite('fishbrain', 'fishbrain', -600, -300);
	setScrollFactor('fishbrain', 1.2, 1.2);
	end	
	}	
	end